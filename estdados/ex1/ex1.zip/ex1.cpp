#include <iostream>
#include <vector>

int contaElementosNegativos( std::vector<int> vetor ){
    /* Entrada: {0, 1, -2, 3, -4} */
    /* Saida: 2 */
    /* Entrada: {0, 0, 0, 0} */
    /* Saida: 0 */
    int contadorNegativos = 0;
    for(const int valor : vetor) {
        if (valor < 0) {
            contadorNegativos++;
        }
    }
    return contadorNegativos;
}

int contaOcorrenciasValor( std::vector<int> vetor, int valor ){
    /* Entrada: {0, 1, -2, 3, -4}, -2 */
    /* Saida: 1 */
    /* Entrada: {0, 0, 0, 0} */
    /* Saida: 4 */
    int contadorOcorrencias = 0;
    for(const int valorAtual : vetor) {
        if (valorAtual == valor) {
            contadorOcorrencias++;
        }
    }
    return contadorOcorrencias;
}

bool temElementosDistintos( std::vector<int> vetor ){
    /* Entrada: {0, 1, -2, 3, -4} */
    /* Saida: true */
    /* Entrada: {0, 0, 0, 0} */
    /* Saida: false */
    for(const int valorAtual : vetor) {
        if (valorAtual != vetor[0]) {
            return true;
        }
    }
    return false;
}

int retornaPosicaoMaiorElemento( std::vector<int> vetor ){
    /* Entrada: {0, 1, -2, 3, -4} */
    /* Saida: 3 */
    /* Entrada: {0, 0, 0, 0} */
    /* Saida: 0 */
    /* A contagem do indice começa no 0 (zero) */
    int posicao = 0;
    int maior = vetor[0];
    for(int i=0; i<vetor.size(); i++) {
        if (vetor[i] > maior) {
            maior = vetor[i];
            posicao = i;
        }
    }
    return posicao;
}

void imprimirVetor( std::vector<int> vetor ) {
    /* Função auxiliar para imprimir um vetor */
    std::cout << "Entrada: { ";
    for(const int valor : vetor) {
        std::cout << valor << " ";
    }
    std::cout << "}";
}
int main () {
    std::cout << "contaElementosNegativos():" << std::endl;
    std::vector<int> a = {0, 1, -2, 3, -4};
    int b;
    imprimirVetor(a);
    b = contaElementosNegativos(a);
    std::cout << std::endl << "Saida: " << b << std::endl;
    a = {0, 0, 0, 0};
    imprimirVetor(a);
    b = contaElementosNegativos(a);
    std::cout << std::endl << "Saida: " << b << std::endl;

    std::cout << std::endl;
    std::cout << "contaOcorrenciasValor():" << std::endl;
    a = {0, 1, -2, 3, -4};
    imprimirVetor(a);
    std::cout << ", " << -2;
    b = contaOcorrenciasValor(a, -2);
    std::cout << std::endl << "Saida: " << b << std::endl;
    a = {0, 0, 0, 0};
    imprimirVetor(a);
    std::cout << ", " << 0;
    b = contaOcorrenciasValor(a, 0);
    std::cout << std::endl << "Saida: " << b << std::endl;

    std::cout << std::endl;
    std::cout << "temElementosDistintos():" << std::endl;
    a = {0, 1, -2, 3, -4};
    imprimirVetor(a);
    bool c;
    c = temElementosDistintos(a);
    std::cout << std::endl << "Saida: " << c << std::endl;
    a = {0, 0, 0, 0};
    imprimirVetor(a);
    c = temElementosDistintos(a);
    std::cout << std::endl << "Saida: " << c << std::endl;

    std::cout << std::endl;
    std::cout << "retornaPosicaoMaiorElemento():" << std::endl;
    a = {0, 1, -2, 3, -4};
    imprimirVetor(a);
    b = retornaPosicaoMaiorElemento(a);
    std::cout << std::endl << "Saida: " << b << std::endl;
    a = {0, 0, 0, 0};
    imprimirVetor(a);
    b = retornaPosicaoMaiorElemento(a);
    std::cout << std::endl << "Saida: " << b << std::endl;
    return 0;
}
